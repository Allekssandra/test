"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var Indicator = (function () {
    function Indicator(id, title, value, minValue, maxValue) {
        this.id = id;
        this.title = title;
        this.value = value;
        this.minValue = minValue;
        this.maxValue = maxValue;
    }
    return Indicator;
}());
var AppComponent = (function () {
    function AppComponent() {
        this.items = [
            { id: "1", title: "Уровень карналита в силосной башни №1", value: 104370, minValue: 1065, maxValue: 106500 },
            { id: "2", title: "Уровень карналита в силосной башни №2", value: 59800, minValue: 998, maxValue: 99800 },
            { id: "3", title: "Уровень карналита в силосной башни №3", value: 21964, minValue: 578, maxValue: 57800 },
            { id: "4", title: "Уровень карналита в силосной башни №4", value: 76393, minValue: 967, maxValue: 96700 },
            { id: "5", title: "Уровень карналита в силосной башни №5", value: 135135, minValue: 1365, maxValue: 136500 },
            { id: "6", title: "Уровень карналита в силосной башни №6", value: 68580, minValue: 1143, maxValue: 114300 },
            { id: "7", title: "Уровень карналита в силосной башни №7", value: 43656, minValue: 856, maxValue: 85600 },
            { id: "8", title: "Уровень карналита в силосной башни №8", value: 86040, minValue: 956, maxValue: 95600 }
        ];
    }
    AppComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            styleUrls: ['app.components.css'],
            selector: 'app',
            templateUrl: 'app.component.html'
        }), 
        __metadata('design:paramtypes', [])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map