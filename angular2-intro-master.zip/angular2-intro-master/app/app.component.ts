import { Component, Input } from '@angular/core';
import { ThrowStmt } from '@angular/compiler/src/output/output_ast';


class Indicator{
    public id: string;
    public title: string;
    public value: number;
    public minValue: number;
    public maxValue: number;

    constructor(id: string, title: string, value: number, minValue: number, maxValue: number) {
  
        this.id = id;
        this.title = title;
        this.value = value;
        this.minValue = minValue;
        this.maxValue = maxValue;
    }     


      
}

@Component({
    moduleId: module.id,
    styleUrls: ['app.components.css'],
    selector: 'app',
    templateUrl: 'app.component.html'
    
})

export class AppComponent {
    
    items: Indicator[] = 
    [
        { id: "1", title: "Уровень карналита в силосной башни №1", value: 104370,minValue: 1065, maxValue: 106500},
        { id: "2", title: "Уровень карналита в силосной башни №2", value: 59800, minValue: 998, maxValue: 99800},
        { id: "3", title: "Уровень карналита в силосной башни №3", value: 21964, minValue: 578, maxValue: 57800 },
        { id: "4", title: "Уровень карналита в силосной башни №4", value: 76393, minValue: 967, maxValue: 96700 },
        { id: "5", title: "Уровень карналита в силосной башни №5", value: 135135,minValue: 1365, maxValue: 136500 },
        { id: "6", title: "Уровень карналита в силосной башни №6", value: 68580, minValue: 1143, maxValue: 114300 },
        { id: "7", title: "Уровень карналита в силосной башни №7", value: 43656, minValue: 856, maxValue: 85600 },
        { id: "8", title: "Уровень карналита в силосной башни №8", value: 86040, minValue: 956, maxValue: 95600 }

    ]; 
   
}



