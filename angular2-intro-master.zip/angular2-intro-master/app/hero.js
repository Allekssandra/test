"use strict";
var Hero = (function () {
    function Hero() {
    }
    return Hero;
}());
exports.Hero = Hero;
exports.HEROES = [
    { name: 'Dr IQ' },
    { name: 'Magneta' },
    { name: 'Bombasto' }
];
//# sourceMappingURL=hero.js.map